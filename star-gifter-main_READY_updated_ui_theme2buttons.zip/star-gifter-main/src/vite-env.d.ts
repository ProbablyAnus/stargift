/// <reference types="vite/client" />

declare module "*.png" {
  const value: string;
  export default value;
}

declare module "*.webp" {
  const value: string;
  export default value;
}

interface ImportMetaEnv {
  readonly VITE_PUBLIC_URL?: string;
  readonly VITE_APP_PUBLIC_URL?: string;
  readonly APP_PUBLIC_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}


declare module "*.svg" {
  const value: string;
  export default value;
}
