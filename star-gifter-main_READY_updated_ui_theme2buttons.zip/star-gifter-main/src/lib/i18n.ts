export const t = (_lang: any, key: string) => key;
